1. install wamp/xampp or ay equivalent web server package
2. copy our files into your "xampp->htdocs" folder (i.e. the root folder of your web server).
3. Start your webserver.
4. Open the index.html file through localhost and you'll see the webpage.
5. click on the movie posters and you'll get the trailer sentiment results along with the trailer video.
6. Please be connected to the internet to get the video playing.

-------------------------------------------------------------------

To setup Python NLTK:-

Installation: http://www.nltk.org/install.html

1. Install Python 3.5: http://www.python.org/downloads/ (avoid the 64-bit versions)
2. Install Numpy (optional): http://sourceforge.net/projects/numpy/files/NumPy/ (the version that specifies python3.5)
3. Install NLTK: http://pypi.python.org/pypi/nltk
	or
   Type in cmd prompt in the python folder: python -m pip install nltk (recommended)

4. Test installation: Start>Python35, then type import nltk
5. install the data and models: nltk.download()
	and download "All packages" to C:\nltk_data